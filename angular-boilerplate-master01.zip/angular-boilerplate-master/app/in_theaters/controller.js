(function(angular){
	'use strict';
	
	var module = angular.module('moviecat.in_theaters',['ngRoute'])
	
	//配置模块的路由
	module.config(['$routeProvider', function($routeProvide){
		$routeProvide.when('/in_theaters',{
			templateUrl:'in_theaters/view.html',
			controller:'InTheatersController'
		});
	}])
	
	module.controller('InTheatersController',[
	'$scope',
	function($scope){
		
	}]);
	
})(angular)
