(function(angular){
	'use strict';
	
	var module = angular.module('moviecat.top250',['ngRoute'])
	
	//配置模块的路由
	module.config(['$routeProvider', function($routeProvide){
		$routeProvide.when('/top250',{
			templateUrl:'top250/view.html',
			controller:'Top250Controller'
		});
	}])
	
	module.controller('InTheatersController',[
	'$scope',
	function($scope){
		
	}]);
	
})(angular)
